import m1 from '../assets/boardMembers/Mamta Savkur.jpg'
import m2 from '../assets/boardMembers/Ashwin Bijur.jpg'
import m3 from '../assets/boardMembers/Neena Karnad.jpeg'
import m4 from '../assets/boardMembers/Shashank_Udyawer.png'
import m5 from '../assets/boardMembers/Sudhir Golikeri.jpg'
import m6 from '../assets/boardMembers/Sumant Padbidri.JPG'

export const boardMembers= [
    {
        name: "Mamta Savkur",
        role: "Board Member",
        img: m1,
      },
    {
        name: "Ashwin Bijur",
        role: "Board Member",
        img: m2,
      },
    {
        name: "Neena Karnad",
        role: "Board Member",
        img: m3,
      },
    {
        name: "Shashank Udyawer",
        role: "Board Member",
        img: m4,
      },
    {
        name: "Sudhir Golikeri",
        role: "Board Member",
        img: m5,
      },
    {
        name: "Sumant Padbidri",
        role: "Board Member",
        img: m6,
      },
]